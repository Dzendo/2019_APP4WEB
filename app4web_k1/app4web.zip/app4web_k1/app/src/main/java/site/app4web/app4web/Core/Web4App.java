package site.app4web.app4web.Core;

public class Web4App extends JasonViewActivity {
   //@Override

}
